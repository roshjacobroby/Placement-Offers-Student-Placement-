import React, { useEffect, useState } from 'react';
import {
  CompaniesByYearReport,
  DrivesByYearReport,
  IndustryParticipationReport,
  RepeatRecruiter,
  PlacementStatsReport,
} from '../types';
import {
  BarChart3,
  Repeat,
  Building2,
  Calendar,
  Award,
  GraduationCap,
  TrendingUp,
  DollarSign,
  CheckCircle2,
  Users,
} from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';

export const ReportsView: React.FC = () => {
  const [placementStats, setPlacementStats] = useState<PlacementStatsReport | null>(null);
  const [companiesByYear, setCompaniesByYear] = useState<CompaniesByYearReport[]>([]);
  const [drivesByYear, setDrivesByYear] = useState<DrivesByYearReport[]>([]);
  const [industryPart, setIndustryPart] = useState<IndustryParticipationReport[]>([]);
  const [repeatRecruiters, setRepeatRecruiters] = useState<RepeatRecruiter[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchReports = async () => {
    setLoading(true);
    try {
      const [statsRes, r1, r2, r3, r4] = await Promise.all([
        fetch('/api/reports/placement-stats').then((res) => res.json()),
        fetch('/api/reports/companies-by-year').then((res) => res.json()),
        fetch('/api/reports/drives-by-year').then((res) => res.json()),
        fetch('/api/reports/industry-participation').then((res) => res.json()),
        fetch('/api/reports/repeat-recruiters').then((res) => res.json()),
      ]);

      setPlacementStats(statsRes);
      setCompaniesByYear(r1);
      setDrivesByYear(r2);
      setIndustryPart(r3);
      setRepeatRecruiters(r4);
    } catch (err) {
      console.error('Failed to load placement reports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const maxOfferCount = Math.max(
    ...(placementStats?.company_wise_offers.map((c) => c.offer_count) || [1])
  );

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center space-x-2">
          <BarChart3 className="w-6 h-6 text-indigo-600" />
          <h1 className="text-xl font-bold text-slate-800">Placement Reports & Insights</h1>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Analytical reports generated directly from normalized student, company, drive, and offer records.
        </p>
      </div>

      {/* Report 1: Core Placement Statistics (Eligible, Placed, Placement %, CTC) */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-2xs font-bold mb-2">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Institutional Executive Summary</span>
            </div>
            <h2 className="text-2xl font-extrabold tracking-tight">Student Placement Performance</h2>
            <p className="text-slate-400 text-xs mt-1">
              Key institutional metrics comparing eligible students against verified placed candidates.
            </p>
          </div>
          <div className="bg-emerald-500/20 border border-emerald-500/30 px-5 py-3 rounded-xl text-center shrink-0">
            <span className="text-3xl font-black text-emerald-400">
              {placementStats?.placement_percentage || 0}%
            </span>
            <span className="text-2xs text-emerald-200 block uppercase font-bold mt-0.5">
              Overall Placement Rate
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
            <div className="flex items-center space-x-2 text-slate-400 text-2xs font-bold uppercase">
              <Users className="w-3.5 h-3.5 text-indigo-400" />
              <span>Eligible Students</span>
            </div>
            <div className="text-2xl font-black text-white mt-1">
              {placementStats?.eligible_students || 0}
            </div>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
            <div className="flex items-center space-x-2 text-slate-400 text-2xs font-bold uppercase">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Students Placed</span>
            </div>
            <div className="text-2xl font-black text-emerald-400 mt-1">
              {placementStats?.students_placed || 0}
            </div>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
            <div className="flex items-center space-x-2 text-slate-400 text-2xs font-bold uppercase">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Highest CTC</span>
            </div>
            <div className="text-2xl font-black text-amber-300 mt-1">
              ₹{placementStats?.salary_stats.max_ctc || 0} LPA
            </div>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
            <div className="flex items-center space-x-2 text-slate-400 text-2xs font-bold uppercase">
              <TrendingUp className="w-3.5 h-3.5 text-indigo-300" />
              <span>Average CTC</span>
            </div>
            <div className="text-2xl font-black text-indigo-300 mt-1">
              ₹{placementStats?.salary_stats.avg_ctc || 0} LPA
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Program-wise Placement & Company-wise Offers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Program-wise Placement */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
            <GraduationCap className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-base">Program-wise Placement Report</h3>
          </div>

          <div className="space-y-3">
            {placementStats?.program_wise_placement.map((prog) => (
              <div key={prog.program} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between mb-1 text-xs">
                  <span className="font-bold text-slate-800">{prog.program}</span>
                  <span className="font-extrabold text-indigo-600">{prog.placement_percentage}% Placed</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-2">
                  <div
                    className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(prog.placement_percentage, 100)}%` }}
                  />
                </div>
                <div className="flex justify-between text-2xs text-slate-500">
                  <span>Eligible: <strong>{prog.eligible}</strong></span>
                  <span>Placed: <strong className="text-emerald-700">{prog.placed}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Company-wise Offers Distribution */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
            <Building2 className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-base">Company-wise Offers Delivered</h3>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
            {placementStats?.company_wise_offers.map((comp) => {
              const pct = maxOfferCount > 0 ? (comp.offer_count / maxOfferCount) * 100 : 0;
              return (
                <div key={comp.company_id} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <div className="flex items-center space-x-2">
                      <CompanyLogo companyName={comp.company_name} size="xs" />
                      <span className="font-bold text-slate-800">{comp.company_name}</span>
                    </div>
                    <span className="font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {comp.offer_count} Offers
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-500 h-2 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="text-2xs text-slate-400 mt-1 block">{comp.industry}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Salary Statistics Deep Dive */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
          <DollarSign className="w-5 h-5 text-emerald-600" />
          <h3 className="font-bold text-slate-800 text-base">Salary Package Statistics (CTC in LPA)</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center">
            <span className="text-2xs uppercase tracking-wider text-slate-500 font-bold block">Minimum Package</span>
            <span className="text-2xl font-black text-slate-800 mt-1 block">
              ₹{placementStats?.salary_stats.min_ctc} LPA
            </span>
          </div>

          <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200 text-center">
            <span className="text-2xs uppercase tracking-wider text-indigo-700 font-bold block">Average Package</span>
            <span className="text-2xl font-black text-indigo-900 mt-1 block">
              ₹{placementStats?.salary_stats.avg_ctc} LPA
            </span>
          </div>

          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-center">
            <span className="text-2xs uppercase tracking-wider text-emerald-700 font-bold block">Maximum Package</span>
            <span className="text-2xl font-black text-emerald-900 mt-1 block">
              ₹{placementStats?.salary_stats.max_ctc} LPA
            </span>
          </div>
        </div>
      </div>

      {/* Repeat Recruiters Report */}
      <div className="bg-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-2xs font-bold mb-2">
              <Repeat className="w-3.5 h-3.5" />
              <span>Core Business Insight • Master Entity Reuse</span>
            </div>
            <h2 className="text-xl font-extrabold text-white tracking-tight">Repeat Recruiters Report</h2>
            <p className="text-slate-300 text-xs mt-1">
              Companies that have conducted <strong>more than one placement drive</strong> across academic years.
            </p>
          </div>
          <div className="bg-indigo-600/30 border border-indigo-400/30 px-4 py-2 rounded-xl text-right shrink-0">
            <span className="text-2xl font-black text-amber-300">{repeatRecruiters.length}</span>
            <span className="text-2xs text-indigo-200 block font-semibold">Repeat Partners</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
          {repeatRecruiters.map((company) => (
            <div
              key={company.company_id}
              className="bg-slate-800/80 border border-slate-700 rounded-xl p-4 shadow-lg flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <CompanyLogo companyName={company.name} size="sm" className="bg-white border-slate-600" />
                    <div>
                      <h3 className="font-extrabold text-white text-base">{company.name}</h3>
                      <p className="text-xs text-indigo-300 font-medium">
                        {company.industry} • {company.location}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-black bg-amber-400 text-slate-950 shadow-sm shrink-0">
                    {company.drive_count} Drives
                  </span>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-700/80 space-y-2">
                  <span className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">
                    Participating Academic Years:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {company.academic_years.map((year) => (
                      <span
                        key={year}
                        className="px-2 py-0.5 rounded text-2xs font-bold bg-indigo-500/20 text-indigo-200 border border-indigo-500/40"
                      >
                        {year}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Grid: Companies by Year & Drives by Year */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
            <Building2 className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-base">Companies Visiting by Academic Year</h3>
          </div>

          <div className="space-y-3">
            {companiesByYear.map((item) => (
              <div key={item.academic_year} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-bold text-slate-800">Academic Year {item.academic_year}</span>
                  <span className="font-extrabold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                    {item.company_count} Unique Companies
                  </span>
                </div>
                <div className="text-2xs text-slate-500 line-clamp-1">
                  {item.companies.join(', ')}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
            <Calendar className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-base">Placement Drives Breakdown by Year</h3>
          </div>

          <div className="space-y-3">
            {drivesByYear.map((item) => (
              <div key={item.academic_year} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-slate-800">AY {item.academic_year}</span>
                  <span className="font-extrabold text-slate-900">{item.drive_count} Drives</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-2xs text-center font-medium">
                  <div className="bg-slate-100 py-1 rounded text-slate-700">Planned: {item.planned_count}</div>
                  <div className="bg-amber-100 py-1 rounded text-amber-800">Ongoing: {item.ongoing_count}</div>
                  <div className="bg-emerald-100 py-1 rounded text-emerald-800">Completed: {item.completed_count}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
