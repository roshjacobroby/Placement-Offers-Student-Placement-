import React from 'react';
import { Network, Database, Key, ShieldCheck, ArrowDown, Check, GraduationCap, Award, Building2, Calendar } from 'lucide-react';

export const ErDiagramView: React.FC = () => {
  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center space-x-2">
          <Network className="w-6 h-6 text-indigo-600" />
          <h1 className="text-xl font-bold text-slate-800">Entity Relationship (ER) & Schema Architecture</h1>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Normalized Relational Database Schema enforcing Master Company entity reuse, Student academic tracking, and Single Accepted Offer rules.
        </p>
      </div>

      {/* Visual ER Diagram Container */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 space-y-8">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-2">
            <Database className="w-5 h-5 text-indigo-400" />
            <h2 className="text-base font-bold">Relational Database Architecture</h2>
          </div>
          <span className="text-2xs bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 px-3 py-1 rounded-full font-mono">
            SQLite Database • 4 Core Normalized Tables
          </span>
        </div>

        {/* ER Diagram Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-stretch">
          {/* Master Entity: COMPANY */}
          <div className="bg-slate-800 rounded-xl border-2 border-indigo-500 p-4 shadow-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="bg-indigo-600 text-white font-extrabold text-2xs px-2.5 py-0.5 rounded shadow-xs uppercase tracking-wider">
                  Master Entity
                </span>
                <Building2 className="w-4 h-4 text-indigo-400" />
              </div>
              <h3 className="text-base font-black text-white mb-2 font-mono">COMPANIES</h3>
              <div className="space-y-1 font-mono text-xs">
                <div className="flex items-center space-x-1.5 text-amber-300 font-bold bg-slate-900/80 p-1.5 rounded">
                  <Key className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>company_id (PK)</span>
                </div>
                <div className="text-slate-200 p-1">name (UNIQUE)</div>
                <div className="text-slate-300 p-1">industry</div>
                <div className="text-slate-300 p-1">location</div>
                <div className="text-slate-400 p-1 text-2xs">created_at</div>
              </div>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-700 text-2xs text-indigo-300 font-medium">
              1 Company : N Drives
            </div>
          </div>

          {/* Entity: PLACEMENT_DRIVES */}
          <div className="bg-slate-800 rounded-xl border-2 border-blue-500 p-4 shadow-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="bg-blue-600 text-white font-extrabold text-2xs px-2.5 py-0.5 rounded shadow-xs uppercase tracking-wider">
                  Drive Drives
                </span>
                <Calendar className="w-4 h-4 text-blue-400" />
              </div>
              <h3 className="text-base font-black text-white mb-2 font-mono">PLACEMENT_DRIVES</h3>
              <div className="space-y-1 font-mono text-xs">
                <div className="flex items-center space-x-1.5 text-amber-300 font-bold bg-slate-900/80 p-1.5 rounded">
                  <Key className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>drive_id (PK)</span>
                </div>
                <div className="flex items-center space-x-1.5 text-indigo-300 font-bold bg-indigo-950/80 p-1.5 rounded border border-indigo-700/60">
                  <Key className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>company_id (FK)</span>
                </div>
                <div className="text-slate-200 p-1">academic_year</div>
                <div className="text-slate-200 p-1">drive_status</div>
                <div className="text-slate-300 p-1">drive_date</div>
              </div>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-700 text-2xs text-blue-300 font-medium">
              1 Drive : N Offers
            </div>
          </div>

          {/* Entity: STUDENTS */}
          <div className="bg-slate-800 rounded-xl border-2 border-emerald-500 p-4 shadow-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="bg-emerald-600 text-white font-extrabold text-2xs px-2.5 py-0.5 rounded shadow-xs uppercase tracking-wider">
                  Candidates
                </span>
                <GraduationCap className="w-4 h-4 text-emerald-400" />
              </div>
              <h3 className="text-base font-black text-white mb-2 font-mono">STUDENTS</h3>
              <div className="space-y-1 font-mono text-xs">
                <div className="flex items-center space-x-1.5 text-amber-300 font-bold bg-slate-900/80 p-1.5 rounded">
                  <Key className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>student_id (PK)</span>
                </div>
                <div className="text-slate-200 p-1">usn (UNIQUE)</div>
                <div className="text-slate-200 p-1">name & email</div>
                <div className="text-slate-300 p-1">program & department</div>
                <div className="text-slate-300 p-1">cgpa & eligibility</div>
              </div>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-700 text-2xs text-emerald-300 font-medium">
              1 Student : N Offers (Max 1 Joined)
            </div>
          </div>

          {/* Entity: OFFERS */}
          <div className="bg-slate-800 rounded-xl border-2 border-amber-500 p-4 shadow-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="bg-amber-600 text-white font-extrabold text-2xs px-2.5 py-0.5 rounded shadow-xs uppercase tracking-wider">
                  Placement Offers
                </span>
                <Award className="w-4 h-4 text-amber-400" />
              </div>
              <h3 className="text-base font-black text-white mb-2 font-mono">OFFERS</h3>
              <div className="space-y-1 font-mono text-xs">
                <div className="flex items-center space-x-1.5 text-amber-300 font-bold bg-slate-900/80 p-1.5 rounded">
                  <Key className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>offer_id (PK)</span>
                </div>
                <div className="flex items-center space-x-1.5 text-emerald-300 font-bold bg-emerald-950/80 p-1 rounded border border-emerald-700/60">
                  <Key className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>student_id (FK)</span>
                </div>
                <div className="flex items-center space-x-1.5 text-blue-300 font-bold bg-blue-950/80 p-1 rounded border border-blue-700/60">
                  <Key className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  <span>drive_id (FK)</span>
                </div>
                <div className="text-slate-200 p-1">ctc (LPA)</div>
                <div className="text-slate-300 p-1">joining_status</div>
              </div>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-700 text-2xs text-amber-300 font-medium">
              Links Candidate to Placement Drive
            </div>
          </div>
        </div>

        {/* System Safeguard Principle */}
        <div className="bg-indigo-950/70 border border-indigo-800/80 rounded-xl p-5 space-y-3">
          <div className="flex items-center space-x-2 text-indigo-300 font-bold text-sm">
            <ShieldCheck className="w-5 h-5 text-indigo-400 shrink-0" />
            <span>Database Constraints & Business Logic Rules</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
            <div>
              <strong className="text-white block mb-1">1. Company Entity Reuse</strong>
              <code className="text-amber-300 font-mono">COMPANIES</code> contains master records. Drives in different academic years link via <code className="text-indigo-300 font-mono">company_id</code> to eliminate duplicate company entries.
            </div>
            <div>
              <strong className="text-white block mb-1">2. Single Accepted Offer Rule</strong>
              A student may hold multiple offer records across different drives, but business logic & database validations strictly prohibit more than 1 offer with <code className="text-emerald-300 font-mono">joining_status = 'Joined'</code>.
            </div>
          </div>
        </div>
      </div>

      {/* Feature Verification Checklist */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-800 flex items-center space-x-2">
          <Check className="w-5 h-5 text-emerald-600" />
          <span>Architectural Integrity Checklist</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-700">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <strong className="text-slate-900 block mb-1">Unique Company Constraint</strong>
            Enforced at SQLite database engine level (`name TEXT UNIQUE NOT NULL`) to stop duplicate company creation.
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <strong className="text-slate-900 block mb-1">Foreign Key Integrity</strong>
            Enabled (`PRAGMA foreign_keys = ON`) so drives and offers reference valid parent records.
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <strong className="text-slate-900 block mb-1">Single Accepted Offer Safeguard</strong>
            Attempting to mark a second offer as 'Joined' for an already placed student returns a 400 Bad Request error.
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <strong className="text-slate-900 block mb-1">Real SQL Aggregate Reports</strong>
            Repeat recruiters, placement percentages, and CTC analytics are computed directly via SQLite aggregation functions.
          </div>
        </div>
      </div>
    </div>
  );
};
