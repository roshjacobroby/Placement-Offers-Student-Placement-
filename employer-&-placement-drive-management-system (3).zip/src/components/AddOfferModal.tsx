import React, { useState, useEffect } from 'react';
import { X, Award, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Student, PlacementDrive, Company } from '../types';

interface AddOfferModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOfferAdded: () => void;
  preselectedStudentId?: number | null;
  preselectedDriveId?: number | null;
}

export const AddOfferModal: React.FC<AddOfferModalProps> = ({
  isOpen,
  onClose,
  onOfferAdded,
  preselectedStudentId,
  preselectedDriveId,
}) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [drives, setDrives] = useState<PlacementDrive[]>([]);

  const [studentId, setStudentId] = useState<string>('');
  const [driveId, setDriveId] = useState<string>('');
  const [ctc, setCtc] = useState('₹8.5 LPA');
  const [offerDate, setOfferDate] = useState(new Date().toISOString().split('T')[0]);
  const [joiningStatus, setJoiningStatus] = useState<'Pending' | 'Joined' | 'Not Joined'>('Joined');
  const [placementStatus, setPlacementStatus] = useState<'Placed' | 'Not Placed'>('Placed');

  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchDropdownData();
    }
  }, [isOpen]);

  useEffect(() => {
    if (preselectedStudentId) {
      setStudentId(String(preselectedStudentId));
    }
    if (preselectedDriveId) {
      setDriveId(String(preselectedDriveId));
    }
  }, [preselectedStudentId, preselectedDriveId, isOpen]);

  const fetchDropdownData = async () => {
    try {
      setFetchingData(true);
      const [studRes, driveRes] = await Promise.all([
        fetch('/api/students'),
        fetch('/api/drives'),
      ]);

      const studData = await studRes.json();
      const driveData = await driveRes.json();

      setStudents(studData);
      setDrives(driveData);

      if (!studentId && studData.length > 0) {
        setStudentId(String(studData[0].student_id));
      }
      if (!driveId && driveData.length > 0) {
        setDriveId(String(driveData[0].drive_id));
      }
    } catch (err) {
      console.error('Error fetching modal data:', err);
    } finally {
      setFetchingData(false);
    }
  };

  if (!isOpen) return null;

  // Real-time rule warning check
  const selectedStudent = students.find((s) => s.student_id === Number(studentId));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!studentId || !driveId || !ctc.trim() || !offerDate) {
      setError('Please fill in all required fields.');
      return;
    }

    try {
      setLoading(true);
      const res = await fetch('/api/offers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student_id: Number(studentId),
          drive_id: Number(driveId),
          ctc: ctc.trim(),
          offer_date: offerDate,
          joining_status: joiningStatus,
          placement_status: placementStatus,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to record offer');
      }

      onOfferAdded();
      onClose();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-200">
          <div className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-800">Record Placement Offer</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-2 text-xs text-red-700">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">Offer Restriction Error</span>
                <span>{error}</span>
              </div>
            </div>
          )}

          {/* Rule Reminder Info Card */}
          <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-lg text-xs text-indigo-900">
            <span className="font-bold text-indigo-900 block mb-0.5">📌 One Accepted Offer Policy</span>
            <span className="text-2xs text-indigo-700 leading-relaxed">
              Students can receive multiple offers, but are restricted to <strong>at most one Joined/Accepted offer</strong>. Setting Joining Status to 'Joined' will verify against existing records.
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Select Student <span className="text-red-500">*</span>
            </label>
            <select
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              disabled={fetchingData}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
              required
            >
              {students.map((s) => (
                <option key={s.student_id} value={s.student_id}>
                  {s.usn} — {s.name} ({s.program})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Select Placement Drive <span className="text-red-500">*</span>
            </label>
            <select
              value={driveId}
              onChange={(e) => setDriveId(e.target.value)}
              disabled={fetchingData}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
              required
            >
              {drives.map((d) => (
                <option key={d.drive_id} value={d.drive_id}>
                  {d.company_name} — AY {d.academic_year} ({d.drive_date})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                CTC Package <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={ctc}
                onChange={(e) => setCtc(e.target.value)}
                placeholder="e.g. ₹9.5 LPA"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 font-medium text-slate-800"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Offer Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={offerDate}
                onChange={(e) => setOfferDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Joining Status</label>
              <select
                value={joiningStatus}
                onChange={(e) => setJoiningStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium"
              >
                <option value="Joined">Joined (Accepted Offer)</option>
                <option value="Pending">Pending (Decision Awaited)</option>
                <option value="Not Joined">Not Joined (Declined / Rejected)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Placement Status</label>
              <select
                value={placementStatus}
                onChange={(e) => setPlacementStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium"
              >
                <option value="Placed">Placed</option>
                <option value="Not Placed">Not Placed</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || fetchingData}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
            >
              {loading ? 'Saving Offer...' : 'Save Placement Offer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
