import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Plus,
  Filter,
  Eye,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Award,
  GraduationCap,
} from 'lucide-react';
import { Student } from '../types';
import { AddStudentModal } from './AddStudentModal';
import { EditStudentModal } from './EditStudentModal';
import { StudentProfileModal } from './StudentProfileModal';

interface StudentsViewProps {
  onAddOfferClick?: (studentId: number) => void;
}

export const StudentsView: React.FC<StudentsViewProps> = ({ onAddOfferClick }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProgram, setSelectedProgram] = useState('ALL');
  const [selectedEligibility, setSelectedEligibility] = useState('ALL');
  const [selectedPlacementStatus, setSelectedPlacementStatus] = useState('ALL');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedStudentForProfile, setSelectedStudentForProfile] = useState<Student | null>(null);
  const [selectedStudentForEdit, setSelectedStudentForEdit] = useState<Student | null>(null);

  const fetchStudents = async () => {
    try {
      setLoading(true);
      setError(null);
      const params = new URLSearchParams();
      if (searchTerm) params.append('search', searchTerm);
      if (selectedProgram !== 'ALL') params.append('program', selectedProgram);
      if (selectedEligibility !== 'ALL') params.append('eligibility', selectedEligibility);
      if (selectedPlacementStatus !== 'ALL') params.append('placement_status', selectedPlacementStatus);

      const res = await fetch(`/api/students?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch students list');
      const data = await res.json();
      setStudents(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, [searchTerm, selectedProgram, selectedEligibility, selectedPlacementStatus]);

  const handleFetchProfileDetail = async (studentId: number) => {
    try {
      const res = await fetch(`/api/students/${studentId}`);
      if (!res.ok) throw new Error('Failed to load profile details');
      const data = await res.json();
      setSelectedStudentForProfile(data);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleDeleteStudent = async (studentId: number, usn: string) => {
    if (!window.confirm(`Are you sure you want to delete student ${usn}? All associated offer records will also be removed.`)) {
      return;
    }

    try {
      const res = await fetch(`/api/students/${studentId}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete student');
      fetchStudents();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Stats calculation
  const totalCount = students.length;
  const eligibleCount = students.filter((s) => s.eligibility === 'Eligible').length;
  const placedCount = students.filter((s) => s.placement_status === 'Placed').length;
  const placementPercentage = eligibleCount > 0 ? ((placedCount / eligibleCount) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-6">
      {/* Header & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <GraduationCap className="w-6 h-6 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-800">Student Placement Profiles</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Manage student eligibility, view individual academic profiles, and track placement offer records.
          </p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Student</span>
        </button>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-2xs font-bold text-slate-500 uppercase tracking-wider block">Total Enrolled</span>
          <span className="text-2xl font-black text-slate-800 mt-1 block">{totalCount}</span>
          <span className="text-2xs text-slate-400 mt-0.5 block">Across all programs</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-2xs font-bold text-emerald-600 uppercase tracking-wider block">Eligible Candidates</span>
          <span className="text-2xl font-black text-emerald-700 mt-1 block">{eligibleCount}</span>
          <span className="text-2xs text-slate-400 mt-0.5 block">Meet eligibility criteria</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-2xs font-bold text-indigo-600 uppercase tracking-wider block">Students Placed</span>
          <span className="text-2xl font-black text-indigo-700 mt-1 block">{placedCount}</span>
          <span className="text-2xs text-slate-400 mt-0.5 block">Received 1+ valid offers</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-2xs font-bold text-slate-500 uppercase tracking-wider block">Placement Rate</span>
          <span className="text-2xl font-black text-slate-900 mt-1 block">{placementPercentage}%</span>
          <span className="text-2xs text-emerald-600 font-medium mt-0.5 block">Of eligible pool</span>
        </div>
      </div>

      {/* Search & Filter Control Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by student USN, Name, or Email..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 md:pb-0">
            <div className="flex items-center space-x-1 shrink-0 text-xs text-slate-500 font-semibold px-1">
              <Filter className="w-3.5 h-3.5" />
              <span>Filters:</span>
            </div>

            <select
              value={selectedProgram}
              onChange={(e) => setSelectedProgram(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Programs</option>
              <option value="BE Computer Science">BE Computer Science</option>
              <option value="BE Information Science">BE Information Science</option>
              <option value="BE Electronics">BE Electronics</option>
              <option value="BE Mechanical">BE Mechanical</option>
              <option value="MCA">MCA</option>
            </select>

            <select
              value={selectedEligibility}
              onChange={(e) => setSelectedEligibility(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Eligibility</option>
              <option value="Eligible">Eligible Only</option>
              <option value="Ineligible">Ineligible Only</option>
            </select>

            <select
              value={selectedPlacementStatus}
              onChange={(e) => setSelectedPlacementStatus(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Placement Status</option>
              <option value="Placed">Placed</option>
              <option value="Not Placed">Not Placed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-500">Loading student directory...</div>
        ) : error ? (
          <div className="p-8 text-center text-xs text-red-600 bg-red-50 flex items-center justify-center space-x-2">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        ) : students.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-xs">
            No students found matching your criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 uppercase tracking-wider text-2xs font-bold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">USN / Roll No</th>
                  <th className="px-4 py-3">Student Name</th>
                  <th className="px-4 py-3">Program & Dept</th>
                  <th className="px-4 py-3">CGPA</th>
                  <th className="px-4 py-3">Eligibility</th>
                  <th className="px-4 py-3">Placement Status</th>
                  <th className="px-4 py-3 text-center">Offers</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {students.map((student) => (
                  <tr key={student.student_id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 font-mono font-bold text-slate-900">{student.usn}</td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-800">{student.name}</div>
                      <div className="text-2xs text-slate-400">{student.email}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-700">{student.program}</div>
                      <div className="text-2xs text-slate-400">{student.department}</div>
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-800">{student.cgpa.toFixed(2)}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-2xs font-bold ${
                          student.eligibility === 'Eligible'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}
                      >
                        {student.eligibility === 'Eligible' ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <XCircle className="w-3 h-3 text-amber-600" />
                        )}
                        <span>{student.eligibility}</span>
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-2xs font-bold ${
                          student.placement_status === 'Placed'
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {student.placement_status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
                          (student.offer_count || 0) > 0
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-400'
                        }`}
                      >
                        {student.offer_count || 0}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right space-x-2 whitespace-nowrap">
                      <button
                        onClick={() => handleFetchProfileDetail(student.student_id)}
                        className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="View Full Profile & Placement History"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setSelectedStudentForEdit(student)}
                        className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                        title="Edit Student Information"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteStudent(student.student_id, student.usn)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Student"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <AddStudentModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onStudentAdded={fetchStudents}
      />

      <StudentProfileModal
        student={selectedStudentForProfile}
        isOpen={!!selectedStudentForProfile}
        onClose={() => setSelectedStudentForProfile(null)}
        onAddOfferClick={onAddOfferClick}
      />

      <EditStudentModal
        student={selectedStudentForEdit}
        isOpen={!!selectedStudentForEdit}
        onClose={() => setSelectedStudentForEdit(null)}
        onStudentUpdated={fetchStudents}
      />
    </div>
  );
};
