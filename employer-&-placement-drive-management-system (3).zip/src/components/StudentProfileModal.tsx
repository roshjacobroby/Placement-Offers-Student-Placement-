import React from 'react';
import { X, User, Award, CheckCircle2, XCircle, Clock, Building2, Calendar, FileText } from 'lucide-react';
import { Student } from '../types';
import { CompanyLogo } from './CompanyLogo';

interface StudentProfileModalProps {
  student: Student | null;
  isOpen: boolean;
  onClose: () => void;
  onAddOfferClick?: (studentId: number) => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  student,
  isOpen,
  onClose,
  onAddOfferClick,
}) => {
  if (!isOpen || !student) return null;

  const history = student.placement_history || [];
  const joinedOffer = history.find((o) => o.joining_status === 'Joined');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 border-b border-slate-800 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-start space-x-4">
            <div className="w-14 h-14 rounded-full bg-indigo-600 flex items-center justify-center text-xl font-bold text-white shadow-inner">
              {student.name.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-bold text-white">{student.name}</h2>
                <span
                  className={`text-2xs font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    student.eligibility === 'Eligible'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {student.eligibility}
                </span>
              </div>
              <p className="text-xs text-indigo-300 font-mono mt-1">{student.usn} • {student.email}</p>
              <p className="text-xs text-slate-300 mt-1">
                {student.program} ({student.department})
              </p>
            </div>
          </div>
        </div>

        {/* Profile Content */}
        <div className="p-6 space-y-6">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
            <div>
              <span className="block text-2xs uppercase tracking-wider text-slate-500 font-semibold">CGPA</span>
              <span className="text-base font-bold text-slate-800">{student.cgpa.toFixed(2)}</span>
            </div>
            <div>
              <span className="block text-2xs uppercase tracking-wider text-slate-500 font-semibold">Offers Count</span>
              <span className="text-base font-bold text-indigo-600">{history.length}</span>
            </div>
            <div>
              <span className="block text-2xs uppercase tracking-wider text-slate-500 font-semibold">Status</span>
              <span
                className={`inline-block text-xs font-bold px-2 py-0.5 rounded-full mt-1 ${
                  student.placement_status === 'Placed'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {student.placement_status || 'Not Placed'}
              </span>
            </div>
            <div>
              <span className="block text-2xs uppercase tracking-wider text-slate-500 font-semibold">Accepted Offer</span>
              <span className="text-xs font-semibold text-slate-800 truncate block mt-1" title={joinedOffer ? joinedOffer.company_name : 'None'}>
                {joinedOffer ? joinedOffer.company_name : 'None'}
              </span>
            </div>
          </div>

          {/* Placement History Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Award className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-800">Placement & Offer History</h3>
              </div>
              {onAddOfferClick && (
                <button
                  onClick={() => {
                    onClose();
                    onAddOfferClick(student.student_id);
                  }}
                  className="px-2.5 py-1 text-2xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors"
                >
                  + Record New Offer
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-500 font-medium">No placement offers recorded for this student yet.</p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 uppercase tracking-wider text-2xs font-semibold border-b border-slate-200">
                    <tr>
                      <th className="px-3 py-2.5">Company</th>
                      <th className="px-3 py-2.5">Academic Year</th>
                      <th className="px-3 py-2.5">CTC</th>
                      <th className="px-3 py-2.5">Offer Date</th>
                      <th className="px-3 py-2.5">Joining Status</th>
                      <th className="px-3 py-2.5">Placement Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white">
                    {history.map((off) => (
                      <tr key={off.offer_id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-3 py-2.5 font-bold text-slate-800">
                          <div className="flex items-center space-x-1.5">
                            <CompanyLogo companyName={off.company_name} size="xs" />
                            <span>{off.company_name}</span>
                          </div>
                        </td>
                        <td className="px-3 py-2.5 text-slate-600 font-mono text-2xs">{off.academic_year}</td>
                        <td className="px-3 py-2.5 font-bold text-emerald-700">{off.ctc}</td>
                        <td className="px-3 py-2.5 text-slate-500 text-2xs">{off.offer_date}</td>
                        <td className="px-3 py-2.5">
                          <span
                            className={`inline-flex items-center space-x-1 text-2xs font-semibold px-2 py-0.5 rounded-full ${
                              off.joining_status === 'Joined'
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                : off.joining_status === 'Pending'
                                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {off.joining_status === 'Joined' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                            {off.joining_status === 'Pending' && <Clock className="w-3 h-3 text-amber-600" />}
                            {off.joining_status === 'Not Joined' && <XCircle className="w-3 h-3 text-slate-400" />}
                            <span>{off.joining_status}</span>
                          </span>
                        </td>
                        <td className="px-3 py-2.5">
                          <span
                            className={`text-2xs font-bold px-2 py-0.5 rounded-full ${
                              off.placement_status === 'Placed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {off.placement_status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
