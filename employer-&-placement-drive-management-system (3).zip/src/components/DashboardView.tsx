import React from 'react';
import { DashboardStats } from '../types';
import { Building2, Calendar, Repeat, Plus, ArrowRight, Layers, CheckCircle2, Users, Award, TrendingUp } from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';

interface DashboardViewProps {
  stats: DashboardStats | null;
  loading: boolean;
  onNavigate: (tab: 'companies' | 'drives' | 'students' | 'offers' | 'reports' | 'acceptance-test') => void;
  onAddCompany: () => void;
  onAddDrive: () => void;
  onAddStudent: () => void;
  onAddOffer: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  loading,
  onNavigate,
  onAddCompany,
  onAddDrive,
  onAddStudent,
  onAddOffer,
}) => {
  if (loading || !stats) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Top Banner & Quick Actions */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl border border-indigo-900/40 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold mb-3">
            <Layers className="w-3.5 h-3.5" />
            <span>Master Company & Placement Drives Portal</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
            Placement & Recruitment Management
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Centralized placement automation suite linking company masters to drives, candidate profiles, and offers while strictly enforcing single accepted offer rules.
          </p>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={onAddCompany}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg font-semibold text-xs shadow-lg transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Company</span>
            </button>
            <button
              onClick={onAddDrive}
              className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 px-4 py-2 rounded-lg font-semibold text-xs transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Schedule Drive</span>
            </button>
            <button
              onClick={onAddStudent}
              className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 px-4 py-2 rounded-lg font-semibold text-xs transition-all"
            >
              <Users className="w-4 h-4" />
              <span>Add Student</span>
            </button>
            <button
              onClick={onAddOffer}
              className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-semibold text-xs transition-all"
            >
              <Award className="w-4 h-4" />
              <span>Record Offer</span>
            </button>
            <button
              onClick={() => onNavigate('acceptance-test')}
              className="flex items-center space-x-2 bg-slate-800/80 hover:bg-slate-700 text-amber-300 border border-amber-500/30 px-3.5 py-2 rounded-lg font-semibold text-xs transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Acceptance Suite</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Companies */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-500">Master Companies</span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{stats.total_companies}</span>
            <span className="text-2xs font-semibold text-emerald-600 block mt-0.5">Unique entities</span>
          </div>
        </div>

        {/* Placement Drives */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-500">Placement Drives</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{stats.total_drives}</span>
            <span className="text-2xs font-semibold text-blue-600 block mt-0.5">Conducted drives</span>
          </div>
        </div>

        {/* Total Students */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-500">Candidate Pool</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{stats.total_students || 0}</span>
            <span className="text-2xs font-bold text-emerald-700 block mt-0.5">
              {stats.placement_percentage || 0}% Placement Rate
            </span>
          </div>
        </div>

        {/* Total Offers */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-500">Placement Offers</span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{stats.total_offers || 0}</span>
            <span className="text-2xs font-bold text-indigo-600 block mt-0.5">
              Avg ₹{stats.avg_ctc || 0} LPA
            </span>
          </div>
        </div>
      </div>

      {/* Two Column Detailed Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Repeat Recruiters Showcase */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Repeat Recruiters</h2>
              <p className="text-xs text-slate-500">Companies conducting multiple placement drives</p>
            </div>
            <button
              onClick={() => onNavigate('reports')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center space-x-1"
            >
              <span>Full Report</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {stats.repeat_recruiters.slice(0, 5).map((company) => (
              <div
                key={company.company_id}
                className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100 hover:border-slate-200 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <CompanyLogo companyName={company.name} size="sm" />
                  <div>
                    <div className="font-semibold text-slate-900 text-xs">{company.name}</div>
                    <div className="text-2xs text-slate-500">
                      {company.industry} • {company.location}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-2xs font-bold bg-indigo-100 text-indigo-800">
                    {company.drive_count} Drives
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Drives by Academic Year */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Drives by Academic Year</h2>
              <p className="text-xs text-slate-500">Year-on-year placement drive distribution</p>
            </div>
            <button
              onClick={() => onNavigate('drives')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center space-x-1"
            >
              <span>View Drives</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4">
            {stats.drives_by_year.map((item) => {
              const maxDrives = Math.max(...stats.drives_by_year.map((d) => d.count), 1);
              const percentage = Math.round((item.count / maxDrives) * 100);

              return (
                <div key={item.academic_year} className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs font-medium">
                    <span className="text-slate-800 font-bold">{item.academic_year}</span>
                    <span className="text-slate-600 font-semibold">{item.count} Drives</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
