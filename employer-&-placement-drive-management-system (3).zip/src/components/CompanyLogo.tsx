import React, { useState } from 'react';
import { Building2 } from 'lucide-react';

interface CompanyLogoProps {
  companyName: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showFallbackText?: boolean;
}

const COMPANY_DOMAINS: Record<string, string> = {
  infosys: 'infosys.com',
  tcs: 'tcs.com',
  wipro: 'wipro.com',
  accenture: 'accenture.com',
  deloitte: 'deloitte.com',
  bosch: 'bosch.com',
  ibm: 'ibm.com',
  'l&t': 'larsentoubro.com',
  'larsen & toubro': 'larsentoubro.com',
  'hdfc bank': 'hdfcbank.com',
  hdfc: 'hdfcbank.com',
  'tata motors': 'tatamotors.com',
  tata: 'tata.com',
  google: 'google.com',
  microsoft: 'microsoft.com',
  amazon: 'amazon.com',
  capgemini: 'capgemini.com',
  cognizant: 'cognizant.com',
  oracle: 'oracle.com',
  cisco: 'cisco.com',
  intel: 'intel.com',
  adobe: 'adobe.com',
  samsung: 'samsung.com',
   Goldman: 'goldmansachs.com',
  'goldman sachs': 'goldmansachs.com',
  'jp morgan': 'jpmorganchase.com',
  jpmorgan: 'jpmorganchase.com',
};

const COMPANY_COLOR_ACCENTS: Record<string, string> = {
  infosys: 'bg-blue-600 text-white',
  tcs: 'bg-indigo-700 text-white',
  wipro: 'bg-teal-600 text-white',
  accenture: 'bg-purple-700 text-white',
  deloitte: 'bg-emerald-700 text-white',
  bosch: 'bg-red-600 text-white',
  ibm: 'bg-blue-800 text-white',
  'l&t': 'bg-amber-600 text-white',
  'hdfc bank': 'bg-blue-900 text-white',
  'tata motors': 'bg-sky-700 text-white',
  google: 'bg-blue-500 text-white',
  microsoft: 'bg-slate-800 text-white',
  amazon: 'bg-amber-500 text-slate-950',
};

export const CompanyLogo: React.FC<CompanyLogoProps> = ({
  companyName,
  size = 'md',
  className = '',
}) => {
  const [imgError, setImgError] = useState(false);

  const cleanName = companyName ? companyName.trim().toLowerCase() : '';
  let domain = COMPANY_DOMAINS[cleanName];

  if (!domain && cleanName) {
    // Try matching partial name
    const foundKey = Object.keys(COMPANY_DOMAINS).find((k) => cleanName.includes(k));
    if (foundKey) {
      domain = COMPANY_DOMAINS[foundKey];
    }
  }

  // Size dimensions
  const sizeMap = {
    xs: 'w-6 h-6 text-2xs',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
    xl: 'w-16 h-16 text-lg',
  };

  const imgSizeMap = {
    xs: 'p-0.5',
    sm: 'p-1',
    md: 'p-1.5',
    lg: 'p-2',
    xl: 'p-2.5',
  };

  const logoUrl = domain ? `https://logo.clearbit.com/${domain}` : null;
  const initial = companyName ? companyName.trim().charAt(0).toUpperCase() : '?';
  const colorStyle = COMPANY_COLOR_ACCENTS[cleanName] || 'bg-indigo-600 text-white';

  if (logoUrl && !imgError) {
    return (
      <div
        className={`${sizeMap[size]} shrink-0 rounded-lg bg-white border border-slate-200 p-1 flex items-center justify-center shadow-2xs overflow-hidden ${className}`}
      >
        <img
          src={logoUrl}
          alt={`${companyName} logo`}
          className="w-full h-full object-contain"
          onError={() => setImgError(true)}
          loading="lazy"
        />
      </div>
    );
  }

  // Clean fallback text avatar
  return (
    <div
      className={`${sizeMap[size]} shrink-0 rounded-lg ${colorStyle} font-bold flex items-center justify-center shadow-2xs ${className}`}
      title={companyName}
    >
      <span>{initial}</span>
    </div>
  );
};
