import React, { useState, useEffect } from 'react';
import {
  Award,
  Search,
  Plus,
  Filter,
  Edit2,
  Trash2,
  CheckCircle2,
  Clock,
  XCircle,
  Building2,
  AlertTriangle,
  FileText,
} from 'lucide-react';
import { Offer, Company } from '../types';
import { AddOfferModal } from './AddOfferModal';
import { EditOfferModal } from './EditOfferModal';
import { CompanyLogo } from './CompanyLogo';

interface OffersViewProps {
  onSelectCompany?: (companyId: number) => void;
  onSelectStudent?: (studentId: number) => void;
  initialStudentId?: number | null;
}

export const OffersView: React.FC<OffersViewProps> = ({
  onSelectCompany,
  onSelectStudent,
  initialStudentId,
}) => {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('ALL');
  const [selectedYear, setSelectedYear] = useState('ALL');
  const [selectedJoiningStatus, setSelectedJoiningStatus] = useState('ALL');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedOfferForEdit, setSelectedOfferForEdit] = useState<Offer | null>(null);

  const fetchOffers = async () => {
    try {
      setLoading(true);
      setError(null);
      const params = new URLSearchParams();
      if (searchTerm) params.append('search', searchTerm);
      if (selectedCompany !== 'ALL') params.append('company_id', selectedCompany);
      if (selectedYear !== 'ALL') params.append('academic_year', selectedYear);
      if (selectedJoiningStatus !== 'ALL') params.append('joining_status', selectedJoiningStatus);

      const res = await fetch(`/api/offers?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch placement offers');
      const data = await res.json();
      setOffers(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchCompaniesList = async () => {
    try {
      const res = await fetch('/api/companies');
      if (res.ok) {
        const data = await res.json();
        setCompanies(data);
      }
    } catch (err) {
      console.error('Error fetching companies:', err);
    }
  };

  useEffect(() => {
    fetchCompaniesList();
  }, []);

  useEffect(() => {
    fetchOffers();
  }, [searchTerm, selectedCompany, selectedYear, selectedJoiningStatus]);

  useEffect(() => {
    if (initialStudentId) {
      setIsAddModalOpen(true);
    }
  }, [initialStudentId]);

  const handleDeleteOffer = async (offerId: number) => {
    if (!window.confirm(`Are you sure you want to delete offer record #${offerId}?`)) return;

    try {
      const res = await fetch(`/api/offers/${offerId}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete offer record');
      fetchOffers();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Metrics
  const totalOffersCount = offers.length;
  const joinedOffersCount = offers.filter((o) => o.joining_status === 'Joined').length;
  const pendingOffersCount = offers.filter((o) => o.joining_status === 'Pending').length;

  return (
    <div className="space-y-6">
      {/* Header & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <Award className="w-6 h-6 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-800">Placement Offers Management</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track recruitment offers, package CTCs, and student joining decisions while strictly enforcing the single accepted offer rule.
          </p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Record New Offer</span>
        </button>
      </div>

      {/* Single Accepted Offer Rule Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start space-x-3 text-xs text-amber-900">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-amber-900 block mb-0.5">Rule Enforcement: One Accepted Offer Per Student</span>
          <p className="text-2xs text-amber-800 leading-relaxed">
            Students may receive multiple offers across different companies and placement drives, but the system restricts each candidate to at most <strong>1 'Joined' (Accepted) offer</strong>. Any attempt to mark a second offer as Joined for the same student will trigger an error.
          </p>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-2xs font-bold text-slate-500 uppercase tracking-wider block">Total Offers Issued</span>
          <span className="text-2xl font-black text-slate-800 mt-1 block">{totalOffersCount}</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-2xs font-bold text-emerald-600 uppercase tracking-wider block">Accepted / Joined Offers</span>
          <span className="text-2xl font-black text-emerald-700 mt-1 block">{joinedOffersCount}</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-2xs font-bold text-amber-600 uppercase tracking-wider block">Pending Decisions</span>
          <span className="text-2xl font-black text-amber-700 mt-1 block">{pendingOffersCount}</span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by student USN, name, or company name..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center space-x-2 overflow-x-auto pb-1 md:pb-0">
            <div className="flex items-center space-x-1 shrink-0 text-xs text-slate-500 font-semibold px-1">
              <Filter className="w-3.5 h-3.5" />
              <span>Filters:</span>
            </div>

            <select
              value={selectedCompany}
              onChange={(e) => setSelectedCompany(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Companies</option>
              {companies.map((c) => (
                <option key={c.company_id} value={c.company_id}>
                  {c.name}
                </option>
              ))}
            </select>

            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Academic Years</option>
              <option value="2025-26">2025-26</option>
              <option value="2024-25">2024-25</option>
              <option value="2023-24">2023-24</option>
            </select>

            <select
              value={selectedJoiningStatus}
              onChange={(e) => setSelectedJoiningStatus(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Joining Status</option>
              <option value="Joined">Joined (Accepted)</option>
              <option value="Pending">Pending</option>
              <option value="Not Joined">Not Joined</option>
            </select>
          </div>
        </div>
      </div>

      {/* Offers Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-500">Loading offer records...</div>
        ) : error ? (
          <div className="p-8 text-center text-xs text-red-600 bg-red-50">{error}</div>
        ) : offers.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-xs">
            No placement offer records found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 uppercase tracking-wider text-2xs font-bold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Offer ID</th>
                  <th className="px-4 py-3">Student Details</th>
                  <th className="px-4 py-3">Recruiting Company</th>
                  <th className="px-4 py-3">Drive Year</th>
                  <th className="px-4 py-3">CTC Package</th>
                  <th className="px-4 py-3">Offer Date</th>
                  <th className="px-4 py-3">Joining Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {offers.map((offer) => (
                  <tr key={offer.offer_id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 font-mono font-bold text-slate-500">#{offer.offer_id}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => onSelectStudent && onSelectStudent(offer.student_id)}
                        className="font-bold text-slate-900 hover:text-indigo-600 hover:underline text-left"
                      >
                        {offer.student_name}
                      </button>
                      <div className="text-2xs text-slate-400 font-mono">{offer.student_usn} • {offer.student_program}</div>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => offer.company_id && onSelectCompany && onSelectCompany(offer.company_id)}
                        className="font-bold text-indigo-600 hover:underline flex items-center space-x-1.5"
                      >
                        <CompanyLogo companyName={offer.company_name} size="xs" />
                        <span>{offer.company_name}</span>
                      </button>
                      <div className="text-2xs text-slate-400 pl-7">{offer.company_industry}</div>
                    </td>
                    <td className="px-4 py-3 font-mono text-2xs text-slate-700">{offer.academic_year}</td>
                    <td className="px-4 py-3 font-extrabold text-emerald-700">{offer.ctc}</td>
                    <td className="px-4 py-3 text-2xs text-slate-500">{offer.offer_date}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center space-x-1 text-2xs font-bold px-2.5 py-0.5 rounded-full ${
                          offer.joining_status === 'Joined'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : offer.joining_status === 'Pending'
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {offer.joining_status === 'Joined' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                        {offer.joining_status === 'Pending' && <Clock className="w-3 h-3 text-amber-600" />}
                        {offer.joining_status === 'Not Joined' && <XCircle className="w-3 h-3 text-slate-400" />}
                        <span>{offer.joining_status}</span>
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right space-x-2">
                      <button
                        onClick={() => setSelectedOfferForEdit(offer)}
                        className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                        title="Edit Offer Record"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteOffer(offer.offer_id)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Offer Record"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <AddOfferModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onOfferAdded={fetchOffers}
        preselectedStudentId={initialStudentId}
      />

      <EditOfferModal
        offer={selectedOfferForEdit}
        isOpen={!!selectedOfferForEdit}
        onClose={() => setSelectedOfferForEdit(null)}
        onOfferUpdated={fetchOffers}
      />
    </div>
  );
};
