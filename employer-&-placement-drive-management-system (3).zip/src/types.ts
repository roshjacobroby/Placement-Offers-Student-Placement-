export interface Company {
  company_id: number;
  name: string;
  industry: string;
  location: string;
  created_at?: string;
  drive_count?: number;
}

export interface PlacementDrive {
  drive_id: number;
  company_id: number;
  company_name?: string;
  industry?: string;
  location?: string;
  academic_year: string;
  eligibility_criteria: string;
  drive_status: 'Planned' | 'Ongoing' | 'Completed';
  drive_date: string;
  created_at?: string;
  offer_count?: number;
  offers?: Offer[];
}

export interface AcademicYear {
  id: number;
  year_name: string;
}

export interface Student {
  student_id: number;
  usn: string;
  name: string;
  email: string;
  program: string;
  department: string;
  cgpa: number;
  eligibility: 'Eligible' | 'Ineligible';
  placement_status?: 'Placed' | 'Not Placed';
  offer_count?: number;
  placement_history?: Offer[];
  created_at?: string;
}

export interface Offer {
  offer_id: number;
  student_id: number;
  student_name?: string;
  student_usn?: string;
  student_program?: string;
  student_department?: string;
  student_email?: string;
  drive_id: number;
  academic_year?: string;
  drive_date?: string;
  company_id?: number;
  company_name?: string;
  company_industry?: string;
  company_location?: string;
  ctc: string;
  ctc_lpa?: number;
  offer_date: string;
  joining_status: 'Pending' | 'Joined' | 'Not Joined';
  placement_status: 'Placed' | 'Not Placed';
  created_at?: string;
}

export interface DashboardStats {
  total_companies: number;
  total_drives: number;
  total_students: number;
  eligible_students: number;
  placed_students: number;
  placement_percentage: number;
  total_offers: number;
  min_ctc: number;
  max_ctc: number;
  avg_ctc: number;
  companies_by_industry: { industry: string; count: number }[];
  drives_by_year: { academic_year: string; count: number }[];
  repeat_recruiters_count: number;
  repeat_recruiters: {
    company_id: number;
    name: string;
    industry: string;
    location: string;
    drive_count: number;
  }[];
}

export interface CompanyWiseOffers {
  company_id: number;
  company_name: string;
  industry: string;
  offer_count: number;
}

export interface ProgramWisePlacement {
  program: string;
  eligible: number;
  placed: number;
  placement_percentage: number;
}

export interface PlacementStatsReport {
  eligible_students: number;
  students_placed: number;
  placement_percentage: number;
  company_wise_offers: CompanyWiseOffers[];
  program_wise_placement: ProgramWisePlacement[];
  salary_stats: {
    min_ctc: number;
    max_ctc: number;
    avg_ctc: number;
    total_offers: number;
  };
}

export interface CompaniesByYearReport {
  academic_year: string;
  company_count: number;
  companies: string[];
}

export interface DrivesByYearReport {
  academic_year: string;
  drive_count: number;
  planned_count: number;
  ongoing_count: number;
  completed_count: number;
}

export interface IndustryParticipationReport {
  industry: string;
  company_count: number;
  drive_count: number;
}

export interface RepeatRecruiter {
  company_id: number;
  name: string;
  industry: string;
  location: string;
  drive_count: number;
  academic_years: string[];
  drives: {
    drive_id: number;
    academic_year: string;
    drive_date: string;
    drive_status: string;
    eligibility_criteria: string;
  }[];
}

