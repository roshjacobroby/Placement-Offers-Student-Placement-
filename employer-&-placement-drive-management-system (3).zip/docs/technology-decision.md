# Technology Decision & Architectural Specification (V05 + V06)

## 1. Technology Stack
- **Frontend**: React 19 + Vite + Tailwind CSS + Lucide Icons
- **Backend**: Node.js + Express
- **Database**: SQLite (via `sql.js` with binary filesystem persistence `v05_placement.db`)
- **Architecture**: Monolithic full-stack web application running on port 3000

---

## 2. Why This Stack Was Chosen
1. **Hackathon & Audit Efficiency**: React + Express + SQLite is fast, reliable, lightweight, and easy to run locally or in container environments without external database setup overhead.
2. **Zero External DB Setup**: SQLite stores all normalized tables locally in `v05_placement.db`. No PostgreSQL/MySQL installation is needed.
3. **Single Port Execution**: Express hosts both the REST API `/api/*` and serves Vite frontend static assets on port `3000`.
4. **Strict Relational Integrity**: SQLite enforces standard SQL Foreign Keys (`PRAGMA foreign_keys = ON`), `UNIQUE` constraints, joins, and aggregate functions (`GROUP BY`, `HAVING`, `AVG`, `MAX`, `MIN`).

---

## 3. Database Schema Specification

### 1. `COMPANIES` (Master Entity - V05)
- `company_id` (INTEGER, Primary Key, Auto Increment)
- `name` (TEXT, UNIQUE, Not Null) — e.g. "Infosys", "Google"
- `industry` (TEXT, Not Null) — e.g. "IT", "Consulting", "Finance"
- `location` (TEXT, Not Null) — e.g. "Bengaluru"
- `created_at` (DATETIME, Default CURRENT_TIMESTAMP)

### 2. `PLACEMENT_DRIVES` (Transaction Table - V05)
- `drive_id` (INTEGER, Primary Key, Auto Increment)
- `company_id` (INTEGER, Foreign Key → `companies.company_id`)
- `academic_year` (TEXT, Not Null) — e.g. "2024-25"
- `eligibility_criteria` (TEXT, Not Null) — e.g. "BE CSE/ISE, CGPA >= 7.0"
- `drive_status` (TEXT, Not Null) — "Planned" | "Ongoing" | "Completed"
- `drive_date` (TEXT, Not Null) — e.g. "2025-10-10"
- `created_at` (DATETIME, Default CURRENT_TIMESTAMP)

### 3. `STUDENTS` (Student Entity - V06)
- `student_id` (INTEGER, Primary Key, Auto Increment)
- `usn` (TEXT, UNIQUE, Not Null) — e.g. "1MS21CS001"
- `name` (TEXT, Not Null) — Candidate name
- `email` (TEXT, UNIQUE, Not Null) — Candidate email
- `program` (TEXT, Not Null) — e.g. "BE Computer Science"
- `department` (TEXT, Not Null) — e.g. "Computer Science & Engineering"
- `cgpa` (REAL, Not Null) — e.g. 8.75
- `eligibility` (TEXT, Not Null) — "Eligible" | "Ineligible"
- `placement_status` (TEXT, Not Null) — "Placed" | "Not Placed"

### 4. `OFFERS` (Outcome Table - V06)
- `offer_id` (INTEGER, Primary Key, Auto Increment)
- `student_id` (INTEGER, Foreign Key → `students.student_id`)
- `drive_id` (INTEGER, Foreign Key → `placement_drives.drive_id`)
- `ctc` (TEXT, Not Null) — e.g. "12.5 LPA"
- `offer_date` (TEXT, Not Null) — e.g. "2025-10-15"
- `joining_status` (TEXT, Not Null) — "Joined" | "Pending" | "Not Joined"
- `placement_status` (TEXT, Not Null) — "Placed" | "Not Placed"

---

## 4. Entity Relationship (ER) Diagram

```text
+-----------------------+              +-----------------------------------+
|       COMPANY         |              |          PLACEMENT_DRIVE          |
+-----------------------+              +-----------------------------------+
| company_id (PK)       | 1          N | drive_id (PK)                     |
| name (UNIQUE)         |<------------>| company_id (FK -> company_id)    |
| industry              |              | academic_year                     |
| location              |              | eligibility_criteria              |
| created_at            |              | drive_status, drive_date          |
+-----------------------+              +-----------------------------------+
                                                         | 1
                                                         |
                                                         | N
+-----------------------+              +-----------------------------------+
|        STUDENT        |              |               OFFER               |
+-----------------------+              +-----------------------------------+
| student_id (PK)       | 1          N | offer_id (PK)                     |
| usn (UNIQUE)          |<------------>| student_id (FK -> student_id)     |
| name, email, program  |              | drive_id (FK -> drive_id)         |
| cgpa, eligibility     |              | ctc, offer_date                   |
| placement_status      |              | joining_status, placement_status  |
+-----------------------+              +-----------------------------------+
```

---

## 5. Architectural Integrity & Rules Enforcement

### Master Entity Reuse (V05)
1. **Schema Constraint**: `companies.name` is marked as `UNIQUE`.
2. **Foreign Keys**: `placement_drives` references `company_id`. Company details are stored once in `companies`.
3. **UI Workflow**: When scheduling a drive, users select from existing master companies or create a new master company if needed.

### Single Accepted Offer Rule (V06)
1. **Multi-Offer Allowance**: A candidate can receive multiple offer records from different companies/drives.
2. **Strict Limit**: A student can have **at most 1 'Joined' (Accepted) offer**.
3. **Validation Safeguard**: When creating or updating an offer to `joining_status = 'Joined'`, the backend checks if the student already holds a `Joined` offer. If so, it rejects the request with HTTP `400 Bad Request` and a descriptive error message.

---

## 6. Dynamic SQL Reports & Calculations

1. **Repeat Recruiters**: Companies conducting > 1 placement drive across years.
2. **Placement Rate**: `(Students Placed / Eligible Students) * 100`.
3. **Company-Wise Offers**: Aggregate count of offers per company entity.
4. **Program-Wise Placement**: Placement percentage categorized by academic program.
5. **Salary Statistics**: `MIN`, `AVG`, `MAX` CTC calculated directly from offer records.

---

## 7. Running the Project Locally

```bash
# 1. Install Dependencies
npm install

# 2. Start Development Server
npm run dev

# 3. Access Application
# Open browser at http://localhost:3000
```

