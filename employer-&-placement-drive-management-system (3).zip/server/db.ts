import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_FILE = path.join(process.cwd(), 'v05_placement.db');

let db: Database | null = null;

function saveDb() {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_FILE, buffer);
}

export async function getDb(): Promise<Database> {
  if (db) return db;

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE)) {
    const fileBuffer = fs.readFileSync(DB_FILE);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  // Create tables with Foreign Key constraints enabled
  db.run(`PRAGMA foreign_keys = ON;`);

  db.run(`
    CREATE TABLE IF NOT EXISTS academic_years (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      year_name TEXT UNIQUE NOT NULL
    );

    CREATE TABLE IF NOT EXISTS companies (
      company_id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      industry TEXT NOT NULL,
      location TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS placement_drives (
      drive_id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_id INTEGER NOT NULL,
      academic_year TEXT NOT NULL,
      eligibility_criteria TEXT NOT NULL,
      drive_status TEXT NOT NULL,
      drive_date TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (company_id) REFERENCES companies(company_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS students (
      student_id INTEGER PRIMARY KEY AUTOINCREMENT,
      usn TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      program TEXT NOT NULL,
      department TEXT NOT NULL,
      cgpa REAL NOT NULL,
      eligibility TEXT NOT NULL DEFAULT 'Eligible',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS offers (
      offer_id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      drive_id INTEGER NOT NULL,
      ctc TEXT NOT NULL,
      ctc_lpa REAL NOT NULL,
      offer_date TEXT NOT NULL,
      joining_status TEXT NOT NULL,
      placement_status TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
      FOREIGN KEY (drive_id) REFERENCES placement_drives(drive_id) ON DELETE CASCADE
    );
  `);

  // Seed default data if empty
  const studentCheck = db.exec('SELECT COUNT(*) as count FROM students');
  const count = studentCheck[0]?.values[0]?.[0] as number || 0;

  if (count === 0) {
    seedDatabase(db);
  } else {
    saveDb();
  }

  return db;
}

export function seedDatabase(database: Database) {
  database.run(`DELETE FROM offers;`);
  database.run(`DELETE FROM students;`);
  database.run(`DELETE FROM placement_drives;`);
  database.run(`DELETE FROM companies;`);
  database.run(`DELETE FROM academic_years;`);

  // Seed Academic Years
  const years = ['2023-24', '2024-25', '2025-26', '2026-27'];
  for (const yr of years) {
    database.run(`INSERT INTO academic_years (year_name) VALUES (?)`, [yr]);
  }

  // Seed 10 Companies across industries
  const companiesData = [
    { name: 'Infosys', industry: 'IT', location: 'Bengaluru' },
    { name: 'TCS', industry: 'IT', location: 'Mumbai' },
    { name: 'Wipro', industry: 'IT', location: 'Bengaluru' },
    { name: 'Accenture', industry: 'Consulting', location: 'Gurugram' },
    { name: 'Deloitte', industry: 'Consulting', location: 'Hyderabad' },
    { name: 'Bosch', industry: 'Manufacturing', location: 'Pune' },
    { name: 'IBM', industry: 'IT', location: 'Bengaluru' },
    { name: 'L&T', industry: 'Engineering', location: 'Mumbai' },
    { name: 'HDFC Bank', industry: 'Banking', location: 'Mumbai' },
    { name: 'Tata Motors', industry: 'Automotive', location: 'Pune' },
  ];

  for (const c of companiesData) {
    database.run(
      `INSERT INTO companies (name, industry, location) VALUES (?, ?, ?)`,
      [c.name, c.industry, c.location]
    );
  }

  // Get company_ids mapped by name
  const res = database.exec(`SELECT company_id, name FROM companies`);
  const companyMap: Record<string, number> = {};
  if (res[0]) {
    for (const row of res[0].values) {
      companyMap[row[1] as string] = row[0] as number;
    }
  }

  // Seed Placement Drives
  const drivesData = [
    { company_name: 'Infosys', academic_year: '2024-25', eligibility_criteria: 'CSE / ISE / ECE, CGPA >= 7.0', drive_status: 'Completed', drive_date: '2024-09-15' },
    { company_name: 'Infosys', academic_year: '2025-26', eligibility_criteria: 'All Engineering branches, CGPA >= 6.5', drive_status: 'Ongoing', drive_date: '2025-10-10' },
    { company_name: 'Infosys', academic_year: '2026-27', eligibility_criteria: 'CSE / ECE, CGPA >= 7.5', drive_status: 'Planned', drive_date: '2026-11-01' },
    { company_name: 'TCS', academic_year: '2024-25', eligibility_criteria: 'B.Tech / M.Tech, CGPA >= 6.0', drive_status: 'Completed', drive_date: '2024-10-20' },
    { company_name: 'TCS', academic_year: '2025-26', eligibility_criteria: 'CSE / IT / ECE, CGPA >= 7.0', drive_status: 'Planned', drive_date: '2025-11-15' },
    { company_name: 'Deloitte', academic_year: '2024-25', eligibility_criteria: 'CSE / ISE / EEE / MBA, CGPA >= 7.5', drive_status: 'Completed', drive_date: '2024-08-12' },
    { company_name: 'Deloitte', academic_year: '2025-26', eligibility_criteria: 'CSE / ISE / Finance, CGPA >= 7.5', drive_status: 'Completed', drive_date: '2025-08-18' },
    { company_name: 'Deloitte', academic_year: '2026-27', eligibility_criteria: 'All B.Tech streams, CGPA >= 8.0', drive_status: 'Planned', drive_date: '2026-09-05' },
    { company_name: 'Accenture', academic_year: '2024-25', eligibility_criteria: 'CSE / IT / Mech, CGPA >= 6.5', drive_status: 'Completed', drive_date: '2024-11-05' },
    { company_name: 'Accenture', academic_year: '2025-26', eligibility_criteria: 'All streams, CGPA >= 6.5', drive_status: 'Ongoing', drive_date: '2025-12-02' },
    { company_name: 'Bosch', academic_year: '2024-25', eligibility_criteria: 'Mech / ECE / EEE, CGPA >= 7.0', drive_status: 'Completed', drive_date: '2024-12-01' },
    { company_name: 'Bosch', academic_year: '2025-26', eligibility_criteria: 'ECE / EEE / Robotics, CGPA >= 7.5', drive_status: 'Planned', drive_date: '2026-01-20' },
    { company_name: 'Wipro', academic_year: '2024-25', eligibility_criteria: 'CSE / ISE, CGPA >= 6.0', drive_status: 'Completed', drive_date: '2024-09-28' },
    { company_name: 'IBM', academic_year: '2025-26', eligibility_criteria: 'CSE / AI-ML, CGPA >= 7.5', drive_status: 'Ongoing', drive_date: '2025-09-14' },
    { company_name: 'L&T', academic_year: '2024-25', eligibility_criteria: 'Civil / Mechanical / Electrical, CGPA >= 7.0', drive_status: 'Completed', drive_date: '2024-07-22' },
    { company_name: 'HDFC Bank', academic_year: '2025-26', eligibility_criteria: 'MBA / B.Tech Data Analytics, CGPA >= 6.5', drive_status: 'Planned', drive_date: '2026-02-10' },
    { company_name: 'Tata Motors', academic_year: '2024-25', eligibility_criteria: 'Automobile / Mech / ECE, CGPA >= 7.0', drive_status: 'Completed', drive_date: '2024-10-02' },
  ];

  for (const d of drivesData) {
    const compId = companyMap[d.company_name];
    if (compId) {
      database.run(
        `INSERT INTO placement_drives (company_id, academic_year, eligibility_criteria, drive_status, drive_date)
         VALUES (?, ?, ?, ?, ?)`,
        [compId, d.academic_year, d.eligibility_criteria, d.drive_status, d.drive_date]
      );
    }
  }

  // Seed 30 Students
  const studentsData = [
    { usn: '1MS21CS001', name: 'Rahul Sharma', email: 'rahul.s@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 8.5, eligibility: 'Eligible' },
    { usn: '1MS21CS002', name: 'Priya Patel', email: 'priya.p@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 9.1, eligibility: 'Eligible' },
    { usn: '1MS21CS003', name: 'Amit Verma', email: 'amit.v@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 7.8, eligibility: 'Eligible' },
    { usn: '1MS21EC001', name: 'Sneha Reddy', email: 'sneha.r@college.edu', program: 'B.Tech ECE', department: 'Electronics', cgpa: 8.8, eligibility: 'Eligible' },
    { usn: '1MS21EC002', name: 'Vikram Singh', email: 'vikram.s@college.edu', program: 'B.Tech ECE', department: 'Electronics', cgpa: 7.4, eligibility: 'Eligible' },
    { usn: '1MS21EC003', name: 'Ananya Roy', email: 'ananya.r@college.edu', program: 'B.Tech ECE', department: 'Electronics', cgpa: 8.2, eligibility: 'Eligible' },
    { usn: '1MS21ME001', name: 'Rohan Kulkarni', email: 'rohan.k@college.edu', program: 'B.Tech Mech', department: 'Mechanical', cgpa: 7.1, eligibility: 'Eligible' },
    { usn: '1MS21ME002', name: 'Neha Gupta', email: 'neha.g@college.edu', program: 'B.Tech Mech', department: 'Mechanical', cgpa: 8.0, eligibility: 'Eligible' },
    { usn: '1MS21CS004', name: 'Karthik Nair', email: 'karthik.n@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 9.4, eligibility: 'Eligible' },
    { usn: '1MS21EE001', name: 'Divya Joshi', email: 'divya.j@college.edu', program: 'B.Tech EEE', department: 'Electrical', cgpa: 7.9, eligibility: 'Eligible' },
    { usn: '1MS21EE002', name: 'Manish Kumar', email: 'manish.k@college.edu', program: 'B.Tech EEE', department: 'Electrical', cgpa: 6.8, eligibility: 'Eligible' },
    { usn: '1MS21CS005', name: 'Pooja Rao', email: 'pooja.r@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 8.9, eligibility: 'Eligible' },
    { usn: '1MS21CS006', name: 'Siddharth Das', email: 'siddharth.d@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 7.6, eligibility: 'Eligible' },
    { usn: '1MS21IS001', name: 'Kavya Hegde', email: 'kavya.h@college.edu', program: 'B.Tech ISE', department: 'Computer Science', cgpa: 8.7, eligibility: 'Eligible' },
    { usn: '1MS21IS002', name: 'Aditya Bhat', email: 'aditya.b@college.edu', program: 'B.Tech ISE', department: 'Computer Science', cgpa: 9.2, eligibility: 'Eligible' },
    { usn: '1MS22MB001', name: 'Ritu Menon', email: 'ritu.m@college.edu', program: 'MBA', department: 'Management', cgpa: 8.4, eligibility: 'Eligible' },
    { usn: '1MS22MB002', name: 'Gaurav Saxena', email: 'gaurav.s@college.edu', program: 'MBA', department: 'Management', cgpa: 7.7, eligibility: 'Eligible' },
    { usn: '1MS22MB003', name: 'Tanvi Shah', email: 'tanvi.s@college.edu', program: 'MBA', department: 'Management', cgpa: 8.1, eligibility: 'Eligible' },
    { usn: '1MS21ME003', name: 'Varun Mehta', email: 'varun.m@college.edu', program: 'B.Tech Mech', department: 'Mechanical', cgpa: 6.9, eligibility: 'Eligible' },
    { usn: '1MS21EC004', name: 'Swati Deshmukh', email: 'swati.d@college.edu', program: 'B.Tech ECE', department: 'Electronics', cgpa: 8.3, eligibility: 'Eligible' },
    { usn: '1MS21CS007', name: 'Abhishek Pillai', email: 'abhishek.p@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 7.2, eligibility: 'Eligible' },
    { usn: '1MS21CS008', name: 'Meera Kapoor', email: 'meera.k@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 8.6, eligibility: 'Eligible' },
    { usn: '1MS21EC005', name: 'Yash Agarwal', email: 'yash.a@college.edu', program: 'B.Tech ECE', department: 'Electronics', cgpa: 7.5, eligibility: 'Eligible' },
    { usn: '1MS21IS003', name: 'Ankita Banerjee', email: 'ankita.b@college.edu', program: 'B.Tech ISE', department: 'Computer Science', cgpa: 8.9, eligibility: 'Eligible' },
    { usn: '1MS22MT001', name: 'Deepa Iyer', email: 'deepa.i@college.edu', program: 'M.Tech CSE', department: 'Computer Science', cgpa: 9.5, eligibility: 'Eligible' },
    { usn: '1MS22MT002', name: 'Chirag Shetty', email: 'chirag.s@college.edu', program: 'M.Tech CSE', department: 'Computer Science', cgpa: 8.8, eligibility: 'Eligible' },
    { usn: '1MS21CV001', name: 'Harish Chandra', email: 'harish.c@college.edu', program: 'B.Tech Civil', department: 'Civil', cgpa: 6.5, eligibility: 'Eligible' },
    { usn: '1MS21CV002', name: 'Sandeep Pandey', email: 'sandeep.p@college.edu', program: 'B.Tech Civil', department: 'Civil', cgpa: 7.0, eligibility: 'Eligible' },
    { usn: '1MS21CS009', name: 'Trisha Sengupta', email: 'trisha.s@college.edu', program: 'B.Tech CSE', department: 'Computer Science', cgpa: 9.0, eligibility: 'Eligible' },
    { usn: '1MS21EC006', name: 'Nikhil Fernandez', email: 'nikhil.f@college.edu', program: 'B.Tech ECE', department: 'Electronics', cgpa: 5.8, eligibility: 'Ineligible' },
  ];

  for (const st of studentsData) {
    database.run(
      `INSERT INTO students (usn, name, email, program, department, cgpa, eligibility)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [st.usn, st.name, st.email, st.program, st.department, st.cgpa, st.eligibility]
    );
  }

  // Get student IDs by USN
  const studentRes = database.exec(`SELECT student_id, usn FROM students`);
  const studentMap: Record<string, number> = {};
  if (studentRes[0]) {
    for (const row of studentRes[0].values) {
      studentMap[row[1] as string] = row[0] as number;
    }
  }

  // Get placement drive IDs mapped by company_name + '_' + academic_year
  const driveRes = database.exec(`
    SELECT pd.drive_id, c.name, pd.academic_year
    FROM placement_drives pd
    JOIN companies c ON pd.company_id = c.company_id
  `);
  const driveMap: Record<string, number> = {};
  if (driveRes[0]) {
    for (const row of driveRes[0].values) {
      const key = `${row[1]}_${row[2]}`;
      driveMap[key] = row[0] as number;
    }
  }

  // Seed 22 Offer records
  // Student Rahul Sharma (1MS21CS001) has 2 offers:
  // 1. Infosys 2024-25 (Joined, Placed)
  // 2. TCS 2024-25 (Pending, Placed)
  const offersData = [
    { student_usn: '1MS21CS001', drive_key: 'Infosys_2024-25', ctc: '₹7.0 LPA', ctc_lpa: 7.0, offer_date: '2024-09-20', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21CS001', drive_key: 'TCS_2024-25', ctc: '₹8.0 LPA', ctc_lpa: 8.0, offer_date: '2024-10-25', joining_status: 'Pending', placement_status: 'Placed' },

    { student_usn: '1MS21CS002', drive_key: 'Infosys_2024-25', ctc: '₹7.0 LPA', ctc_lpa: 7.0, offer_date: '2024-09-20', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21CS002', drive_key: 'Deloitte_2024-25', ctc: '₹9.5 LPA', ctc_lpa: 9.5, offer_date: '2024-08-20', joining_status: 'Pending', placement_status: 'Placed' },

    { student_usn: '1MS21CS003', drive_key: 'Wipro_2024-25', ctc: '₹6.5 LPA', ctc_lpa: 6.5, offer_date: '2024-10-05', joining_status: 'Joined', placement_status: 'Placed' },

    { student_usn: '1MS21EC001', drive_key: 'Bosch_2024-25', ctc: '₹8.5 LPA', ctc_lpa: 8.5, offer_date: '2024-12-10', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21EC002', drive_key: 'Accenture_2024-25', ctc: '₹6.8 LPA', ctc_lpa: 6.8, offer_date: '2024-11-15', joining_status: 'Pending', placement_status: 'Placed' },

    { student_usn: '1MS21EC003', drive_key: 'Deloitte_2024-25', ctc: '₹9.0 LPA', ctc_lpa: 9.0, offer_date: '2024-08-20', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21EC003', drive_key: 'Accenture_2024-25', ctc: '₹6.8 LPA', ctc_lpa: 6.8, offer_date: '2024-11-15', joining_status: 'Not Joined', placement_status: 'Placed' },

    { student_usn: '1MS21ME001', drive_key: 'Tata Motors_2024-25', ctc: '₹7.2 LPA', ctc_lpa: 7.2, offer_date: '2024-10-15', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21ME002', drive_key: 'Bosch_2024-25', ctc: '₹8.5 LPA', ctc_lpa: 8.5, offer_date: '2024-12-10', joining_status: 'Joined', placement_status: 'Placed' },

    { student_usn: '1MS21CS004', drive_key: 'Infosys_2025-26', ctc: '₹7.5 LPA', ctc_lpa: 7.5, offer_date: '2025-10-15', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21EE001', drive_key: 'L&T_2024-25', ctc: '₹6.2 LPA', ctc_lpa: 6.2, offer_date: '2024-08-01', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21CS005', drive_key: 'IBM_2025-26', ctc: '₹12.0 LPA', ctc_lpa: 12.0, offer_date: '2025-09-25', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21CS006', drive_key: 'TCS_2024-25', ctc: '₹7.0 LPA', ctc_lpa: 7.0, offer_date: '2024-10-25', joining_status: 'Joined', placement_status: 'Placed' },

    { student_usn: '1MS21IS001', drive_key: 'Deloitte_2025-26', ctc: '₹10.0 LPA', ctc_lpa: 10.0, offer_date: '2025-08-25', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21IS002', drive_key: 'IBM_2025-26', ctc: '₹12.0 LPA', ctc_lpa: 12.0, offer_date: '2025-09-25', joining_status: 'Joined', placement_status: 'Placed' },

    { student_usn: '1MS22MB001', drive_key: 'HDFC Bank_2025-26', ctc: '₹8.2 LPA', ctc_lpa: 8.2, offer_date: '2026-02-15', joining_status: 'Pending', placement_status: 'Placed' },
    { student_usn: '1MS22MB002', drive_key: 'Deloitte_2024-25', ctc: '₹9.0 LPA', ctc_lpa: 9.0, offer_date: '2024-08-20', joining_status: 'Joined', placement_status: 'Placed' },

    { student_usn: '1MS22MT001', drive_key: 'Infosys_2025-26', ctc: '₹9.5 LPA', ctc_lpa: 9.5, offer_date: '2025-10-15', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS22MT002', drive_key: 'IBM_2025-26', ctc: '₹14.0 LPA', ctc_lpa: 14.0, offer_date: '2025-09-25', joining_status: 'Joined', placement_status: 'Placed' },
    { student_usn: '1MS21CS009', drive_key: 'Deloitte_2025-26', ctc: '₹11.0 LPA', ctc_lpa: 11.0, offer_date: '2025-08-25', joining_status: 'Joined', placement_status: 'Placed' },
  ];

  for (const o of offersData) {
    const sId = studentMap[o.student_usn];
    const dId = driveMap[o.drive_key];
    if (sId && dId) {
      database.run(
        `INSERT INTO offers (student_id, drive_id, ctc, ctc_lpa, offer_date, joining_status, placement_status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [sId, dId, o.ctc, o.ctc_lpa, o.offer_date, o.joining_status, o.placement_status]
      );
    }
  }

  saveDb();
}

// Database helper functions
export function execQuery(database: Database, sql: string, params: any[] = []) {
  const stmt = database.prepare(sql);
  stmt.bind(params);
  const rows: any[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}
